import { AppRegistry } from 'react-native';
import App from './src/native';

AppRegistry.registerComponent('universalreact', () => App);
