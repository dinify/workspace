export const SIZES = {
  desktop: 992,
  tablet: 768,
  phone: 376,
};

export default [SIZES];
