export const getRestaurant = appState => appState.restaurant;
